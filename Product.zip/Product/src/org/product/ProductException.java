package org.product;


public class ProductException extends RuntimeException {
    public ProductException(String message) {
        super(message);
    }
}
