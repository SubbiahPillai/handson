package org.product;

import java.util.*;
import org.product.ProductException;
import org.product.Product;
import java.sql.Date;

public class ProductDaoImpl implements ProductDao {
    private Map<Integer, Product> productStore = new HashMap<>();

    public ProductDaoImpl() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, Calendar.MAY);
        calendar.set(Calendar.DAY_OF_MONTH, 21);
        Date purchasingDate = new Date(calendar.getTimeInMillis());
        
        productStore.put(1, new Product(1, "Samsung Mobile", 18000, 1, "NewModel", purchasingDate));
        productStore.put(2, new Product(2, "Vivo Mobile", 20000, 2, "Nice", purchasingDate));
        productStore.put(3, new Product(3, "Mi TV", 42000, 4, "High Quality", purchasingDate));
        productStore.put(4, new Product(4, "Mi Laptop", 67000, 1, "Professional", purchasingDate));
    }
    
    @Override
    public void createProduct(Product product) {
        if (productStore.containsKey(product.getProductId())) {
            throw new ProductException("Product with ID " + product.getProductId() + " already exists.");
        }
        productStore.put(product.getProductId(), product);
    }
    
    @Override
    public void updateProduct(Product product) {
        if (!productStore.containsKey(product.getProductId())) {
            throw new ProductException("Product with ID " + product.getProductId() + " not found.");
        }
        productStore.put(product.getProductId(), product);
    }
    
    @Override
    public void deleteProduct(int productId) {
        if (!productStore.containsKey(productId)) {
            throw new ProductException("Product with ID " + productId + " not found.");
        }
        productStore.remove(productId);
    }
    
    @Override
    public Product getProductById(int productId) {
        Product product = productStore.get(productId);
        if (product == null) {
            throw new ProductException("Product with ID " + productId + " not found.");
        }
        return product;
    }
    
    @Override
    public List<Product> getAllProducts() {
        return new ArrayList<>(productStore.values());
    }
}
