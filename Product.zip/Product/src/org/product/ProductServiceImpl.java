package org.product;


import java.util.List;
import org.product.ProductDao;
import org.product.ProductDaoImpl;
import org.product.Product;

public class ProductServiceImpl implements ProductService {
    private ProductDao productDao = new ProductDaoImpl();
    
    @Override
    public void addProduct(Product product) {
        productDao.createProduct(product);
    }
    
    @Override
    public void updateProduct(Product product) {
        productDao.updateProduct(product);
    }
    
    @Override
    public void deleteProduct(int productId) {
        productDao.deleteProduct(productId);
    }
    
    @Override
    public Product getProduct(int productId) {
        return productDao.getProductById(productId);
    }
    
    @Override
    public List<Product> getAllProducts() {
        return productDao.getAllProducts();
    }
}
