package org.product;

import java.sql.Date;
import java.util.Collection;
import java.util.Scanner;
import org.product.ProductException;
import org.product.Product;
import org.product.ProductService;
import org.product.ProductServiceImpl;

public class ProductManagementApp {
    private static ProductService productService = new ProductServiceImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
           
            System.out.println("1. Show All Products");
            System.out.println("2. Find Product By ProductId");
            System.out.println("3. Add Product");
            System.out.println("4. Update Product");
            System.out.println("5. Delete Product");
            System.out.println("6. Exit");
            System.out.print("Choose the option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            
            
            switch (choice) {
                case 1:
                    showAllProducts();
                    break;
                case 2:
                    findProductById();
                    break;
                case 3:
                    addProduct();
                    break;
                case 4:
                    updateProduct();
                    break;
                case 5:
                    deleteProduct();
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option, please try again");
            }
        }
    }

    private static void showAllProducts() {
        try {
            Collection<Product> products = productService.getAllProducts();
            if (products == null || products.isEmpty()) {
                System.out.println("No products found.");
                return;
            }

            for (Product product : products) {
                System.out.println(product);
            }
            System.out.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void findProductById() {
        try {
            System.out.println("Enter the Product Id");
            int id = scanner.nextInt();
            scanner.nextLine(); 
            Product product = productService.getProduct(id);
            if (product != null) {
                System.out.println(product);
            } else {
                System.out.println("Product not found.");
            }
            System.out.println();
        } catch (ProductException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static void addProduct() {
        try {
            Product product = new Product();
            System.out.println("Enter Product Id:");
            product.setProductId(scanner.nextInt());
            scanner.nextLine(); 
            System.out.println("Enter Product Name:");
            product.setProductName(scanner.nextLine());
            System.out.println("Enter Product Price:");
            product.setPrice(scanner.nextDouble());
            System.out.println("Enter Quantity in Hand:");
            product.setQuantityInHand(scanner.nextInt());
            scanner.nextLine();
            System.out.println("Enter Description:");
            product.setDescription(scanner.nextLine());
            System.out.println("Enter Order Date (yyyy-mm-dd):");
            product.setOrderDate(Date.valueOf(scanner.nextLine()));

            productService.addProduct(product);
            System.out.println("Product added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
private static void updateProduct() {
        try {
            System.out.println("Enter the Product Id to update:");
            int id = scanner.nextInt();
            scanner.nextLine(); 
            Product existingProduct = productService.getProduct(id);

            if (existingProduct != null) {
                System.out.println("Enter new Product Name:");
                existingProduct.setProductName(scanner.nextLine());
                System.out.println("Enter new Product Price:");
                existingProduct.setPrice(scanner.nextDouble());
                System.out.println("Enter new Quantity in Hand:");
                existingProduct.setQuantityInHand(scanner.nextInt());
                scanner.nextLine(); 
                System.out.println("Enter new Description:");
                existingProduct.setDescription(scanner.nextLine());
                System.out.println("Enter new Order Date (yyyy-mm-dd):");
                existingProduct.setOrderDate(Date.valueOf(scanner.nextLine()));

                productService.updateProduct(existingProduct);
                System.out.println("Product updated successfully!");
            } else {
                System.out.println("Product not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void deleteProduct() {
        try {
            System.out.println("Enter Product ID to delete:");
            int deleteId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            productService.deleteProduct(deleteId);
            System.out.println("Product deleted successfully!");
        } catch (ProductException ex) {
            System.out.println(ex.getMessage());
        }
    }
}