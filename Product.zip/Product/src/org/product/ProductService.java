package org.product;

import java.util.List;
import org.product.Product;

public interface ProductService {
    void addProduct(Product product);
    void updateProduct(Product product);
    void deleteProduct(int productId);
    Product getProduct(int productId);
    List<Product> getAllProducts();
}
