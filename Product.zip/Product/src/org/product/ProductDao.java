package org.product;

import java.util.List;
import org.product.Product;

public interface ProductDao {
    void createProduct(Product product);
    void updateProduct(Product product);
    void deleteProduct(int productId);
    Product getProductById(int productId);
    List<Product> getAllProducts();
}
