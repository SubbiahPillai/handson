package org.string;
@FunctionalInterface
	 public interface StringTest {
		boolean test(String s);
}
