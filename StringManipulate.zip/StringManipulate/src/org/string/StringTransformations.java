package org.string;

public class StringTransformations {
public static StringTransform uppercaseLambda = s -> s.toUpperCase();
    
    public static StringTransform reverseLambda = s -> new StringBuilder(s).reverse().toString();
}
