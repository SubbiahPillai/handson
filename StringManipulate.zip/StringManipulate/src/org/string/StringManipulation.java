package org.string;
import java.util.function.Function;


public class StringManipulation {
    public static Function<String, String> insertSpaceLambda = s -> String.join(" ", s.split(""));
}