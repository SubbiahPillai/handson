package org.string;


import java.util.function.BiPredicate;

public class Authentication {
	   public static BiPredicate<String, String> authenticationLambda = (username, password) ->
	           username.equals("subbiah") && password.equals("123");
	}


