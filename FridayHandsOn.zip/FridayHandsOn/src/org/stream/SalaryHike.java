package org.stream;

import org.stream.Employee;

import java.util.List;

public class SalaryHike {
    public static void listSalaryIncrease(List<Employee> employees) {
        employees.stream()
                .forEach(emp -> {
                    double increasedSalary = emp.getSalary() * 1.15;
                    System.out.println(emp.getFirstName() + " " + emp.getLastName() + " - " +
                            "Current Salary: " + emp.getSalary() +
                            ", Increased Salary: " + increasedSalary);
                });
    }
}
