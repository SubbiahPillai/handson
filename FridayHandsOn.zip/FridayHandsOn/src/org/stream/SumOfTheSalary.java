package org.stream;

import org.stream.Employee;

import java.util.List;

public class SumOfTheSalary {
    public static double calculateTotalSalary(List<Employee> employees) {
        return employees.stream()
                .mapToDouble(Employee::getSalary)
                .sum();
    }
}
