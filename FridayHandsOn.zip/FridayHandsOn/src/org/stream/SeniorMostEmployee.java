package org.stream; 

import org.stream.Employee;

import java.util.Comparator;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class SeniorMostEmployee {
    public static Employee findSeniorMostEmployee(List<Employee> employees) {
        return employees.stream()
                .max(Comparator.comparing(Employee::getHireDate))
                .orElse(null);
    }
}
