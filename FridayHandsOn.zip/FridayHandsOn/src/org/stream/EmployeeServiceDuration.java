package org.stream;

import org.stream.Employee;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class EmployeeServiceDuration {
    public static void listEmployeeServiceDuration(List<Employee> employees) {
        employees.stream()
                .forEach(emp -> {
                    long months = emp.getHireDate().until(LocalDate.now(), ChronoUnit.MONTHS);
                    long days = emp.getHireDate().until(LocalDate.now(), ChronoUnit.DAYS) % 30; // Assuming 30 days per month
                    System.out.println(emp.getFirstName() + " " + emp.getLastName() + " - " +
                            months + " months " + days + " days");
                });
    }
}
