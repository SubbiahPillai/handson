package org.stream;

import org.stream.Employee;
import java.util.List;
import java.util.stream.Collectors;


public class EmployeeWithOutDepartment {
    public static List<Employee> findEmployeesWithoutDepartment(List<Employee> employees) {
        return employees.stream()
                .filter(emp -> emp.getDepartment() == null || emp.getDepartment().isEmpty())
                .collect(Collectors.toList());
    }
}
