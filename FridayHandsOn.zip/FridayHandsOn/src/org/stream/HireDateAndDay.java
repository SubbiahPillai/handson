package org.stream;

import org.stream.Employee;

import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

public class HireDateAndDay {
    public static void listEmployeeHireDateAndDay(List<Employee> employees) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE", Locale.ENGLISH);
        employees.stream()
                .forEach(emp -> {
                    String dayOfWeek = emp.getHireDate().format(formatter);
                    System.out.println(emp.getFirstName() + " " + emp.getLastName() + " - " +
                            emp.getHireDate() + " (" + dayOfWeek + ")");
                });
    }
}
