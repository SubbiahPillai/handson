package org.stream;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Employee> employees = createSampleEmployeeList();

        double totalSalary = SumOfTheSalary.calculateTotalSalary(employees);
        System.out.println("Total salary of all employees: " + totalSalary);
        System.out.println("_____________________________________________________________");
       
        Employee seniorMostEmployee = SeniorMostEmployee.findSeniorMostEmployee(employees);
        System.out.println("Senior most employee: " + seniorMostEmployee.getFirstName() + " " + seniorMostEmployee.getLastName());
        System.out.println("_____________________________________________________________");

        System.out.println("Employee service duration:");
        EmployeeServiceDuration.listEmployeeServiceDuration(employees);
        System.out.println("_____________________________________________________________");

        List<Employee> employeesWithoutDepartment = EmployeeWithOutDepartment.findEmployeesWithoutDepartment(employees);
        System.out.println("Employees without department:");
        employeesWithoutDepartment.forEach(emp -> System.out.println(emp.getFirstName() + " " + emp.getLastName()));
        System.out.println("_____________________________________________________________");

        System.out.println("Employee hire date and day of week:");
        HireDateAndDay.listEmployeeHireDateAndDay(employees);
        System.out.println("_____________________________________________________________");

        System.out.println("Employee salary and 15% increase:");
        SalaryHike.listSalaryIncrease(employees);
        System.out.println("_____________________________________________________________");

        List<Employee> employeesWithoutManager = EmployeesWithoutManager.findEmployeesWithoutManager(employees);
        System.out.println("Employees without manager:");
        employeesWithoutManager.forEach(emp -> System.out.println(emp.getFirstName() + " " + emp.getLastName()));
    }

    private static List<Employee> createSampleEmployeeList() {
        List<Employee> employees = new ArrayList<>();

        employees.add(new Employee(1, "Ramesh", "Santhosh", "ramesh12@gmail.com",
                "12345", LocalDate.of(2015, 1, 1), "Manager", 150000, 0, "IT"));
        employees.add(new Employee(2, "Jhon", "Ram", "jhon@gmail.com",
                "87651", LocalDate.of(2019, 5, 15), "Engineer", 40000, 21, "Engineering"));
        employees.add(new Employee(3, "Suresh", "Krishna", "suresh12@gmail.com",
                "89123", LocalDate.of(2021, 8, 20), "Analyst", 35000, 12, "Engineering"));
        employees.add(new Employee(4, "Murugan", "Kannan", "murugan12@gmail.com",
                "21987", LocalDate.of(2021, 10, 10), "Assistant", 30000, 32, "HR"));
        
        return employees;
    }
}
