package org.local;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class LocalDateDuration {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first date (YYYY-MM-DD): ");
        String inputDate1 = scanner.nextLine();

        System.out.print("Enter the second date (YYYY-MM-DD): ");
        String inputDate2 = scanner.nextLine();

        LocalDate date1 = LocalDate.parse(inputDate1, DateTimeFormatter.ISO_LOCAL_DATE);
        LocalDate date2 = LocalDate.parse(inputDate2, DateTimeFormatter.ISO_LOCAL_DATE);

        printDurationBetweenDates(date1, date2);
    }

    public static void printDurationBetweenDates(LocalDate date1, LocalDate date2) {
        Period period = calculatePeriodBetweenDates(date1, date2);

        int years = period.getYears();
        int months = period.getMonths();
        int days = period.getDays();

      
        System.out.println("Duration between the two dates:");
        System.out.println("Years: " + years);
        System.out.println("Months: " + months);
        System.out.println("Days: " + days);
    }

    public static Period calculatePeriodBetweenDates(LocalDate date1, LocalDate date2) {
        return Period.between(date1, date2);
    }
}
