package org.lambda;

public interface Operation {
	String operate(String s);

}
