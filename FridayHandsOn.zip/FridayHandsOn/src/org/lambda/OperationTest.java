package org.lambda;

public class OperationTest {
	public static String applyOperation(String s,Operation operation) {
		return operation.operate(s);
	}
	public static void main(String[] args) {
		Operation reverse = s -> new StringBuilder(s).reverse().toString();
		String input="Hello World!";
		String result = applyOperation(input,reverse);
		
		System.out.println("Original:" + input);
		System.out.println("reversed:" + result);
		
	}
}
