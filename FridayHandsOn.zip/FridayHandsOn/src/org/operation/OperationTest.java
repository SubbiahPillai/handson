package org.operation;

public class OperationTest {

	    public static void main(String[] args) {
	        Arithmetic addition = (a, b) -> a + b;
	        Arithmetic subtraction = (a, b) -> a - b;
	        Arithmetic multiplication = (a, b) -> a * b;
	        Arithmetic division = (a, b) -> {
	            if (b == 0) {
	                throw new ArithmeticException("Division by zero is not allowed.");
	            }
	            return a / b;
	        };

	 
	        double a = 34;
	        double b = 45;

	        System.out.println("Addition: " + performOperation(a, b, addition));
	        System.out.println("Subtraction: " + performOperation(a, b, subtraction));
	        System.out.println("Multiplication: " + performOperation(a, b, multiplication));
	        System.out.println("Division: " + performOperation(a, b, division));
	    }

	
	    public static double performOperation(double a, double b, Arithmetic operation) {
	        return operation.operate(a, b);
	    }
	}


