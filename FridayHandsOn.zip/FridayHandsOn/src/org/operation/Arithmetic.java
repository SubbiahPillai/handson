package org.operation;

@FunctionalInterface
public interface Arithmetic {
    double operate(double a, double b);
}


