package org.string;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string for transformation: ");
        String originalString = scanner.nextLine();
        System.out.println("Uppercase: " + StringTransformations.uppercaseLambda.transform(originalString));
        System.out.println("Reversed: " + StringTransformations.reverseLambda.transform(originalString));

        System.out.print("\nEnter a string to test palindrome: ");
        String testPalindrome = scanner.nextLine();
        System.out.println("Is palindrome? " + StringTests.palindromeLambda.test(testPalindrome));
        
        System.out.print("\nEnter a string to test contains 'a': ");
        String testContainsChar = scanner.nextLine();
        System.out.println("Contains 'a'? " + StringTests.containsCharLambda.test(testContainsChar));

        System.out.print("\nEnter two numbers for power calculation (x y): ");
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        System.out.println("x^y = " + MathOperations.powerLambda.apply(x, y));

        scanner.nextLine(); 

        System.out.print("\nEnter a string to insert spaces between characters: ");
        String spaceInput = scanner.nextLine();
        System.out.println("Space separated: " + StringManipulation.insertSpaceLambda.apply(spaceInput));

        
        System.out.print("\nEnter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.println("Is authenticated? " + Authentication.authenticationLambda.test(username, password));

        scanner.close();
    }
}
