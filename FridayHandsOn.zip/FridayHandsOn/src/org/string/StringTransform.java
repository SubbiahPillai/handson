package org.string;

@FunctionalInterface
	  


public interface StringTransform {
	
	        String transform(String s);
	    }

