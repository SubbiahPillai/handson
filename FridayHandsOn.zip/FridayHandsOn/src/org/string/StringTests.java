package org.string;

public class StringTests {
	public static StringTest palindromeLambda = s -> {
        String reversed = new StringBuilder(s).reverse().toString();
        return s.equals(reversed);
    };
    
    public static StringTest containsCharLambda = s -> s.contains("a"); 
    
}
