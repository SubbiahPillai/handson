package org.string;

	import java.util.function.BiFunction;

	public class MathOperations {
	    public static BiFunction<Integer, Integer, Double> powerLambda = (x, y) -> Math.pow(x, y);
	}


