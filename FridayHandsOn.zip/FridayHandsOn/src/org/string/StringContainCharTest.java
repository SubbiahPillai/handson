package org.string;

public interface StringContainCharTest{
    boolean test(String s, char c);
}
