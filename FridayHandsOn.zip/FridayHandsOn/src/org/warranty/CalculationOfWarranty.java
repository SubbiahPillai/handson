package org.warranty;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class CalculationOfWarranty {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the product purchase date (YYYY-MM-DD): ");
        String purchaseDateInput = scanner.nextLine();

        System.out.print("Enter the warranty period in years: ");
        int warrantyYears = scanner.nextInt();
        System.out.print("Enter the warranty period in months: ");
        int warrantyMonths = scanner.nextInt();

        LocalDate purchaseDate = LocalDate.parse(purchaseDateInput, DateTimeFormatter.ISO_LOCAL_DATE);

        LocalDate warrantyExpiryDate = calculateWarrantyExpiryDate(purchaseDate, warrantyYears, warrantyMonths);

        System.out.println("Warranty expires on: " + warrantyExpiryDate);
    }

    public static LocalDate calculateWarrantyExpiryDate(LocalDate purchaseDate, int years, int months) {
        return purchaseDate.plusYears(years).plusMonths(months);
    }
}
