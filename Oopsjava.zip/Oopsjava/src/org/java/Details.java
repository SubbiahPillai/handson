package org.java;
import java.util.Scanner;

public class Details{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Firstname:");
		String ch=sc.nextLine();
		System.out.println("Enter the Lastname :");
		String ch1=sc.nextLine();
		System.out.println("Enter the Gender:");
		String ch2=sc.nextLine();
		System.out.println("Enter the Age:");
		int ch3=sc.nextInt();
		System.out.println("Enter the Weight:");
		float ch4=sc.nextFloat();
			System.out.println("Person Details:");
			System.out.println("_____________________");
			System.out.println("First Name: "+ch);
			System.out.println("Last Name: "+ch1);
			System.out.println("Gender: "+ch2);    
			System.out.println("Age: "+ch3);   
     		System.out.println("Weight: "+ch4);
 }

}
