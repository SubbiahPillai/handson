package org.java;

public class Employeeinsurance {
		   public static void main(String[] args){
		   	Employees emp1 = new Employees(1, "Saranya", "Female", 24, 15000, "System Associate");
		   	Employees emp2 = new Employees(2, "Subbiah", "Male", 25, 30000, "Programmer");
	        Employees emp3 = new Employees(3, "keerthy", "Female", 35, 50000, "Manager");
	        Employees emp4 = new Employees(4, "Santhosh", "Male", 25, 4000, "Clerk");

	        emp1.displayEmployeeDetails();
	        System.out.println();
	        emp2.displayEmployeeDetails();
	        System.out.println();
	        emp3.displayEmployeeDetails();
	        System.out.println();
	        emp4.displayEmployeeDetails();
	        System.out.println();
	    	}
	   	}


