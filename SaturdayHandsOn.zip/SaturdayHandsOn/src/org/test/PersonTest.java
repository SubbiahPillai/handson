package org.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PersonTest {

    @Test
    public void testConstructor_NullFirstAndLastName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person(null, null);
        });
        assertEquals("Both Names Cannot be NULL", exception.getMessage());
    }

    @Test
    public void testConstructor_ValidFirstAndLastName() {
        Person person = new Person("Subbiah", "Pillai");
        assertNotNull(person);
        assertEquals("Subbiah", person.getFirstName());
        assertEquals("Pillai", person.getLastName());
    }

    @Test
    public void testGetFullName_BothNamesNotNull() {
        Person person = new Person("Subbiah", "Pillai");
        assertEquals("Subbiah Pillai", person.getFullName());
    }

    @Test
    public void testGetFullName_FirstNameNull() {
        Person person = new Person(null, "Pillai");
        assertEquals("? Pillai", person.getFullName());
    }

    @Test
    public void testGetFullName_LastNameNull() {
        Person person = new Person("Subbiah", null);
        assertEquals("Subbiah ?", person.getFullName());
    }

    @Test
    public void testGetFirstName() {
        Person person = new Person("Subbiah", "Pillai");
        assertEquals("Subbiah", person.getFirstName());
    }

    @Test
    public void testGetLastName() {
        Person person = new Person("Subbiah", "Pillai");
        assertEquals("Pillai", person.getLastName());
    }
}
