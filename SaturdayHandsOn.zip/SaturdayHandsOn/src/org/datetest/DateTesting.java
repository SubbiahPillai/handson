package org.datetest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DateTesting {
    private DateTest date;

    @BeforeEach
    public void setUp() {
        date = new DateTest(1, 1, 2023); 
    }

    @Test
    public void testConstructor() {
        assertEquals(1, date.getDay());
        assertEquals(1, date.getMonth());
        assertEquals(2023, date.getYear());
    }

    @Test
    public void testSetDay() {
        date.setDay(10);
        assertEquals(10, date.getDay());
    }

    @Test
    public void testSetMonth() {
        date.setMonth(12);
        assertEquals(12, date.getMonth());
    }

    @Test
    public void testSetYear() {
        date.setYear(2024);
        assertEquals(2024, date.getYear());
    }

    @Test
    public void testToString() {
        assertEquals("Date is 1/1/2023", date.toString());
    }
}
