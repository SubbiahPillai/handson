package org.wiprojava;
import java.util.Scanner;
public class PositiveString {

		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        String choice;

		        do {
		            System.out.print("Enter a string: ");
		            String input = scanner.nextLine();

		            if (isPositiveString(input)) {
		                System.out.println(input + " is a positive string.");
		            } else {
		                System.out.println(input + " is not a positive string.");
		            }

		            System.out.print("Do you want to enter another string? (yes/no): ");
		            choice = scanner.nextLine().trim().toLowerCase();
		        } while (choice.equals("yes"));

		        scanner.close();
		        System.out.println("Program terminated.");
		    }

		    public static boolean isPositiveString(String str) {
		        int n = str.length();

		        for (int i = 0; i < n - 1; i++) {
		            if (str.charAt(i) > str.charAt(i + 1)) {
		                return false;
		            }
		        }

		        return true;
		    }
		
	}


