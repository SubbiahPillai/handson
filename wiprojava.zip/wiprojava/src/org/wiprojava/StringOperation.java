package org.wiprojava;

import java.util.Scanner;

public class StringOperation {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter a string:");
            String inputString = scanner.nextLine();

            System.out.println("Choose an option:");
            System.out.println("1. Add the String to itself");
            System.out.println("2. Replace odd positions with # ");
            System.out.println("3. Remove duplicate characters in the String");
            System.out.println("4. Change odd characters to upper case");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    String doubledString = addStringToItself(inputString);
                    System.out.println("Result: " + doubledString);
                    break;
                case 2:
                    String oddReplacedString = replaceOddPositions(inputString);
                    System.out.println("Result: " + oddReplacedString);
                    break;
                case 3:
                    String uniqueCharsString = removeDuplicateCharacters(inputString);
                    System.out.println("Result: " + uniqueCharsString);
                    break;
                case 4:
                    String oddToUpperString = changeOddCharactersToUpperCase(inputString);
                    System.out.println("Result: " + oddToUpperString);
                    break;
                case 5:
                    System.out.println("Exiting the program...");
                    scanner.close();
                    return; 
                default:
                    System.out.println("Invalid . Please enter a valid option.");
                    break;
            }
        }
    }

    private static String addStringToItself(String input) {
        return input + input;
    }

    private static String replaceOddPositions(String input) {
        StringBuilder result = new StringBuilder(input);
        for (int i = 0; i < result.length(); i++) {
            if (i % 2 != 0) {
                result.setCharAt(i, '#');
            }
        }
        return result.toString();
    }

    private static String removeDuplicateCharacters(String input) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (result.indexOf(String.valueOf(currentChar)) == -1) {
                result.append(currentChar);
            }
        }
        return result.toString();
    }

    private static String changeOddCharactersToUpperCase(String input) {
        StringBuilder result = new StringBuilder(input);
        for (int i = 0; i < result.length(); i++) {
            if (i % 2 == 0) {
                char originalChar = result.charAt(i);
                char upperChar = Character.toUpperCase(originalChar);
                result.setCharAt(i, upperChar);
            }
        }
        return result.toString();
    }
}
