package org.wiprojava;

public class palindrome {

	public static void main(String[] args) {
		String str="MalayalaM";
		StringBuilder str1=new StringBuilder(str);
		str1.reverse();
		
		if (str.equals(str1.toString()))
		{
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not palindrome");
		}
    }

	

}
