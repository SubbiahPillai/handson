package org.wiprojava;
import java.util.Scanner;

public class reversed {

	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        String input;

		        while (true) {
		        
		            System.out.print("Enter a string (type 'exit' to quit):");
		            input = scanner.nextLine();

		            if (input.equalsIgnoreCase("exit")) {
		                System.out.println("Exiting the program...");
		                break;
		            }
		            String reversed = new StringBuilder(input).reverse().toString();
		            System.out.println("Reversed string: " + reversed);
		        }

		        scanner.close();
		    }

	}