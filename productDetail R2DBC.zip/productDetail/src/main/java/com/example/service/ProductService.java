package com.example.service;

import com.example.product.Product;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ProductService {

	Mono<Product> getProductById(int id);
	Flux<Product> getAllProducts();
	Mono<Product>createProduct(Product product);
	Mono<Void>updateProduct(int id,Product product);
	Mono<Void>deleteProduct(int id);
}
