package com.example.service;

import org.springframework.stereotype.Service;

import com.example.product.Product;
import com.example.repository.ProductRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductServiceImpl implements ProductService {
	
	private final ProductRepository productRepository;
	
	public ProductServiceImpl (ProductRepository productRepository) {
		this.productRepository = productRepository;
	}
	

	@Override
	public Mono<Product> getProductById(int id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id);
	}

	@Override
	public Flux<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Mono<Product> createProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Mono<Void> updateProduct(int id, Product product) {
		// TODO Auto-generated method stub
		return productRepository.findById(id)
				.flatMap(existingProduct -> {
                    existingProduct.setProduct_name(product.getProduct_name());
                    existingProduct.setPrice(product.getPrice());
                    existingProduct.setQuantity(product.getQuantity());
                    return productRepository.save(existingProduct);
                })
                .then();
			
			}

	@Override
	public Mono<Void> deleteProduct(int id) {
		// TODO Auto-generated method stub
		return productRepository.deleteById(id);
	}

}
