package com.example.router;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;
import static org.springframework.web.reactive.function.server.RequestPredicates.*;

import com.example.handler.ProductHandler;

import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;
import static org.springframework.web.reactive.function.server.RequestPredicates.PUT;
import static org.springframework.web.reactive.function.server.RequestPredicates.DELETE;

@Configuration
public class ProductRouter {

    @Bean
    public RouterFunction<ServerResponse> routes(ProductHandler handler) {
        return route(GET("/productinfo/{id}"), handler::getProductById)
                .andRoute(GET("/productinfo"), handler::getAllProducts)
                .andRoute(POST("/productinfo"), handler::createProduct)
                .andRoute(PUT("/productinfo/{id}"), handler::updateProduct)
                .andRoute(DELETE("/productinfo/{id}"), handler::deleteProduct);
    }
} 
