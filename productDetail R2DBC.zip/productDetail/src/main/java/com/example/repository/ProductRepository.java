package com.example.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.example.product.Product;

public interface ProductRepository extends ReactiveCrudRepository<Product, Integer> {

}
