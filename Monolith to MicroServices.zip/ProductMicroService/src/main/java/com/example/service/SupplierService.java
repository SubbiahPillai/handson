package com.example.service;

import java.util.List;

import com.example.entity.Supplier;

public interface SupplierService {
	List<Supplier> getSuppliers();
	Supplier getSupplierById(int id);
	Supplier addSupplier(Supplier supplier);
	Supplier updateSupplier(int id,Supplier supplier);
	void deleteSupplier(int id);

}
