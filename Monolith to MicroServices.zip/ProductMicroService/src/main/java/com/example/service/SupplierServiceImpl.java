package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entity.Supplier;
import com.example.repository.SupplierRepository;

@Service
public class SupplierServiceImpl implements SupplierService {

	private SupplierRepository supplierRepository;
	
	public SupplierServiceImpl(SupplierRepository supplierRepository) {
		this.supplierRepository=supplierRepository;
	}
	@Override
	public List<Supplier> getSuppliers() {
		// TODO Auto-generated method stub
		return supplierRepository.findAll();
	}

	@Override
	public Supplier getSupplierById(int id) {
		// TODO Auto-generated method stub
		return supplierRepository.findById(id)
				.orElseThrow(()->new RuntimeException("Supplier Not Found"));
		
	}

	@Override
	public Supplier addSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return supplierRepository.save(supplier);
	}

	@Override
	public Supplier updateSupplier(int id, Supplier supplier){
		// TODO Auto-generated method stub
		Supplier existingSupplier = supplierRepository.findById(id)
				.orElseThrow(()-> new RuntimeException("Supplier not Found"));
		if(supplier.getSupplierName() != null) {
			existingSupplier.setSupplierName(supplier.getSupplierName());;
		}
		if(supplier.getProduct() != null) {
			existingSupplier.setProduct(supplier.getProduct());
		}
			return supplierRepository.save(existingSupplier);
		

	
	}

	@Override
	public void deleteSupplier(int id) {
		// TODO Auto-generated method stub
		supplierRepository.deleteById(id);

	}

}
