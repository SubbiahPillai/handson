package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Product;
import com.example.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id)
				.orElseThrow(()->new RuntimeException("location Not Found"));
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(int id, Product product) {
		// TODO Auto-generated method stub
		Product existingProduct= productRepository.findById(id)
				.orElseThrow(()->new RuntimeException("Employee not found"));
		if (product.getProductName()!=null) {
			existingProduct.setProductName(product.getProductName());
		}
		return productRepository.save(existingProduct);
	
	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		productRepository.deleteById(id);

	}

}
